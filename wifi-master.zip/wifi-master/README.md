Hack WIFI dengan Aplikas Termux untuk bobol password wifi 

masukan kode perintah wajib di bawah ini
 apt update
apt upgrade
apt install git
apt install wget
apt install proot
pkg install curl
pkg install clang
pkg install tsudo
pkg install tsu

kemudian anda download script hack wifi seperti di bawah ini
 git clone https://github.com/kumpulanremaja/wifi
 cd wifi
chmod +x wifi-hacker.sh
sh wifi-hacker.sh


untuk selengkapnya cek di https://www.kumpulanremaja.com/2019/09/bobol-wifi-dengan-termux.html
